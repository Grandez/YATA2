/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

DELETE FROM `FIATS`;
/*!40000 ALTER TABLE `FIATS` DISABLE KEYS */;
INSERT INTO `FIATS` (`ID`, `SYMBOL`, `NAME`, `ICON`, `EXCHANGE`, `CRYPTO`) VALUES
	(1, 'BTC', 'Bitcoin', '1.png', 1, 1),
	(2, 'AUD', 'Dolar Australiano', 'FLAG_AUD.png', 1, 0),
	(3, 'BRL', 'Real Brasileiro', 'BRL.png', 1, 0),
	(4, 'CAD', 'Dolar Canadiense', 'FLAG_CAD.png', 1, 0),
	(5, 'CHF', 'Franco Suizo', 'FLAG_CHF.png', 1, 0),
	(6, 'CNY', 'Yuan Chino', 'FLAG_CNY.png', 1, 0),
	(7, 'DKK', 'Corona Danesa', 'FLAG_DKK.png', 1, 0),
	(10, 'INR', 'Rupia India', 'FLAG_INR.png', 1, 0),
	(11, 'ISK', 'Corona Islandesa', 'FLAG_ISK.png', 1, 0),
	(12, 'JPK', 'Yen Japones', 'FLAG_JPK.png', 1, 0),
	(13, 'MXN', 'Peso Mexicano', 'FLAG_MXN.png', 1, 0),
	(14, 'NOK', 'Corona Noruega', 'FLAG_NOK.png', 1, 0),
	(15, 'NZD', 'Dolar Neozelandes', 'FLAG_NZD.png', 1, 0),
	(16, 'PEN', 'Sol Peruano', 'FLAG_PEN.png', 1, 0),
	(17, 'SEK', 'Corona Sueca', 'FLAG_SEK.png', 1, 0),
	(19, 'XAG', 'Plata troy', 'XAG_01.png', 1, 0),
	(20, 'XAU', 'Oro troy', 'XAU_01.png', 1, 0),
	(1027, 'ETH', 'Ethereum', '1027.png', 1, 1),
	(2781, 'USD', 'US Dolar', 'FLAG_USD.png', 1, 0),
	(2790, 'EUR', 'Euro', 'FLAG_EUR.png', 1, 0),
	(2791, 'GBP', 'Libra Esterlina', 'FLAG_GBP.png', 1, 0),
	(2821, 'ARS', 'Peso Argentino', 'FLAG_ARS.png', 1, 0);
/*!40000 ALTER TABLE `FIATS` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
