# YATABatch

Conjunto de procesos que se ejecutan:

- En segundo plano
- En Batch
- Por linea de comandos

**No SON COMANDOS DE GESTION DE YATACLI**
Mas bien comandos administrativos y utilidades
